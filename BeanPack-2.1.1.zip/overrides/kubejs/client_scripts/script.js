// priority: 0

console.info('Hello, World! (You will see this line every time client resources reload)')

onEvent('jei.hide.items', event => {
	event.hide('mekanism:portable_teleporter')
	event.hide('mekanism:teleporter')
	event.hide('mekanism:teleporter_frame')
	event.hide(Item.of('mekanism:portable_teleporter', '{mekData:{EnergyContainers:[{Container:0b,stored:"1000000"}]}}'))
})